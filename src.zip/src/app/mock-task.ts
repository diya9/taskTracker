import { Task } from './Task';

export const TASKS: Task[]=[
    {
        id: 1,
        text: 'Doctor Appointment',
        day: 'May 5th at 2.30pm',
        reminder: true
    },
    {
        id: 2,
        text: 'DSM',
        day: 'May 2nd at 2pm',
        reminder: true
    },
    {
        id: 3,
        text: 'Check Jira',
        day: 'May 1st at 9.30am',
        reminder: false
    },
    {
        id: 4,
        text: 'Lunch Break',
        day: 'May 6th at 3pm',
        reminder: true
    }
];